<?php
    //session_start();
    include("usuarios.php");
    session_start();

    $baseDatos = new usuarios();

    $notas = $_POST;
    
    for($i = 0;$i < (count($notas)-1)/9;$i = $i+1){
        $baseDatos->updateNotas($notas["codigo_mtr".$i], $notas['cod_curso'],$notas["grupo".$i],$notas["estado".$i],
        $notas["continua1".$i],$notas["continua2".$i],$notas["continua3".$i],$notas["examen1".$i]
        ,$notas["examen2".$i],$notas["examen3".$i]);
    }
    
?>